﻿@echo off
chcp 65001 >nul
title VBTM Pro 3.6.0 - Go Cai Dat
echo Dang go cai dat VBTM Pro Add-in khoi Microsoft Word...
"%~dp0VBTM-Pro.exe" --uninstall
echo Hoan tat!
pause
