﻿@echo off
chcp 65001 >nul
title VBTM Pro 3.6.0 - Cai Dat Ngoai Tuyen (Offline Edition)
echo ========================================================================
echo    VBTM PRO 3.6.0: CAI DAT NGOAI TUYEN CHO MICROSOFT WORD (OFFLINE)
echo    Khong can quyen Admin - Khong can Internet - Tuong thich Word 32/64-bit
echo ========================================================================
echo.
echo [1/2] Dang dang ky Add-in Ribbon VBTM Pro 3.6 vao Microsoft Word...
"%~dp0VBTM-Pro.exe" --install-word
echo [2/2] Hoan tat! Hay mo Microsoft Word va kiem tra Tab "VBTM Pro 3.6 (05-HD & ND30)".
echo.
pause
